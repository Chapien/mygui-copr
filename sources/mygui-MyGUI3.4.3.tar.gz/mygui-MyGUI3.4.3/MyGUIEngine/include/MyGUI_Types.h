/*
 * This source file is part of MyGUI. For the latest info, see http://mygui.info/
 * Distributed under the MIT License
 * (See accompanying file COPYING.MIT or copy at http://opensource.org/licenses/MIT)
 */

#ifndef MYGUI_TYPES_H_
#define MYGUI_TYPES_H_

#include "MyGUI_Prerequest.h"

#include <cstdint>
#include <vector>
#include <map>
#include <string>

#include "MyGUI_Align.h"
#include "MyGUI_TPoint.h"
#include "MyGUI_TSize.h"
#include "MyGUI_TRect.h"
#include "MyGUI_TCoord.h"

namespace MyGUI
{

	// определяем типы
	using IntPoint = types::TPoint<int>;
	using FloatPoint = types::TPoint<float>;

	using IntSize = types::TSize<int>;
	using FloatSize = types::TSize<float>;

	using IntRect = types::TRect<int>;
	using FloatRect = types::TRect<float>;

	using IntCoord = types::TCoord<int>;
	using FloatCoord = types::TCoord<float>;
	using DoubleCoord = types::TCoord<double>;

	using MapString = std::map<std::string, std::string, std::less<>>;
	using VectorString = std::vector<std::string>;
	using PairString = std::pair<std::string, std::string>;
	using VectorStringPairs = std::vector<PairString>;

	// TODO: remove this types
	using uint8 = uint8_t;
	using uint16 = uint16_t;
	using uint32 = uint32_t;

	using Char = unsigned int;

} // namespace MyGUI

#endif // MYGUI_TYPES_H_
